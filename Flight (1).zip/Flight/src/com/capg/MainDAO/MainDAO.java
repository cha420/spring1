package com.capg.MainDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.capg.Flight.Flight;
import com.capg.Flight.Flightuser;
import com.capg.Register.UserRegister;
import com.capg.utils.DBconfig;
//import com.capg.utils.Dbconfig;
//import com.capg.utils.Dbconfig;

public class MainDAO {
	List<UserRegister> listusers= new ArrayList<UserRegister>();
	List <Flightuser> list=new ArrayList<>();
	List<Flight> f=new ArrayList<>();
	public boolean saveUserDetail( UserRegister user){
		if(listusers.add(user))
			return true;
		else
			return false;
		
	}
	public Flight searchFlight(int flight_id) {
		Flight flight = null;
		for(Flight e: f) {
			if(e.getFlightId()==flight_id) {
				flight=e;
			break;
			}
			
		}
		return flight;
		
		
	}
	public void bookFlight(Flightuser user) {
		list.add(user);
	}
	public void cancelFlight(int flightId){
		
		for(Flightuser e: list) {
			if(e.getFligthId()==flightId) {
				list.remove(e);
			break;
			}
			
		}
		
		
		
	}
	public Flightuser viewFlight(int flightId) {
		Flightuser flight = null;
		for(Flightuser e: list) {
			if(e.getFligthId()==flightId) {
				flight=e;
			break;
			}
			
		}
		return flight;
		
	}
	
	public void addallFlight(){
		
		f.add(new Flight("airindia",1,2000,"hyderabad","mumbai"));
		f.add(new Flight("Indigo",2,4000,"pune","chennai"));
		f.add(new Flight("spiceJet",3,5000,"Bangalore","hyderabad"));
		f.add(new Flight("Airlines",4,2000,"goa","gujarat"));
	}

}
