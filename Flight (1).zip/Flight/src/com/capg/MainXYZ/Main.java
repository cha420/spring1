package com.capg.MainXYZ;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.capg.Flight.Flight;
import com.capg.Flight.Flightuser;
import com.capg.MainDAO.MainDAO;
import com.capg.Register.UserRegister;

public class Main {

	public static void main(String[] args) {
		Scanner s= new Scanner(System.in);
		MainDAO dao= new MainDAO();
		dao.addallFlight();
		int registrationNumber =0;
		int choice=0;
		while(choice!=6){
			System.out.println("Welcome to xyz flight system");
			System.out.println("1.Enter 1 for Registration ");
			System.out.println("2.Enter 2 for View/Search fligth details ");
			System.out.println("3.Enter 3 for ticket booking");
			System.out.println("4. Enter 4 cancelling the tickets");
			System.out.println("5. Enter 5 View tickets");
			System.out.println("6 Enter 6 for exit");
			choice=s.nextInt();
			switch(choice) {
			case 1:
				System.out.println("Enter the Name ");
				String name=s.next();
				System.out.println("Enter the moblie number ");
				String moblienumber=s.next();
				System.out.println("Enter the City ");
				String City=s.next();
				registrationNumber++;
				boolean added = dao.saveUserDetail(new UserRegister(registrationNumber,name,moblienumber,City));
				if(added)
					System.out.println("added succesfully");
				break;
			case 2:
				System.out.println("Enter the flight details");
				System.out.println("Enter the flight id");
				int flightId=s.nextInt();
				Flight flight=dao.searchFlight(flightId);
				System.out.println(flight);
				break;
			case 3:
				System.out.println("Enter the source");
				String source= s.next();
				System.out.println("Enter the Destination");
				String destination= s.next();
				System.out.println("Enter the flight id");
				int flightId1=s.nextInt();
				System.out.println("Enter the user  name");
				String username= s.next();
				dao.bookFlight(new Flightuser(source,destination,flightId1,username));
				break;	
			case 4:
				System.out.println("Enter the flightId");
				int flightId2=s.nextInt();
				dao.cancelFlight(flightId2);
				break;
			case 5:
				System.out.println("Enter the flightId");
				int flightId3=s.nextInt();
				Flightuser result=dao.viewFlight(flightId3);
				System.out.println(result);
				break;
				
			case 6:
				choice=6;
				break;
				
			}
			
			
			
		}
		
		
		
	}

}
