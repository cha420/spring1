package com.capg.Register;

public class UserRegister {
	private int RegisterNo;
	private String Name;
	private String moblieNumber;
	private String city;
	
	public UserRegister() {
		super();
	}

	public UserRegister(int registerNo, String name, String moblieNumber, String city) {
		super();
		this.RegisterNo = registerNo;
		this.Name = name;
		this.moblieNumber = moblieNumber;
		this.city = city;
	}

	public int getRegisterNo() {
		return RegisterNo;
	}

	public void setRegisterNo(int registerNo) {
		RegisterNo = registerNo;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getMoblieNumber() {
		return moblieNumber;
	}

	public void setMoblieNumber(String moblieNumber) {
		this.moblieNumber = moblieNumber;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Override
	public String toString() {
		return "UserRegister [RegisterNo=" + RegisterNo + ", Name=" + Name + ", moblieNumber=" + moblieNumber
				+ ", city=" + city + "]";
	}
	

	
	

}
