package com.capg.Flight;

public class Flightuser {
	String source;
	String destination;
	int fligthId;
	String username;
	public Flightuser(String source, String destination, int fligthId, String username) {
		super();
		this.source = source;
		this.destination = destination;
		this.fligthId = fligthId;
		this.username = username;
	}
	public Flightuser() {
		super();
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public int getFligthId() {
		return fligthId;
	}
	public void setFligthId(int fligthId) {
		this.fligthId = fligthId;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	@Override
	public String toString() {
		return "Flightuser [source=" + source + ", destination=" + destination + ", fligthId=" + fligthId
				+ ", username=" + username + "]";
	}
	

}
