package com.capg.Flight;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Flight {
	private String flightname;
	private int flightId;
	private double fare;
	private  String source;
	private String destination;
	
	public Flight() {
		super();
	}

	public Flight(String flightname, int flightId, double fare, String source, String destination) {
		super();
		this.flightname = flightname;
		this.flightId = flightId;
		this.fare = fare;
		this.source = source;
		this.destination = destination;
	}

	public String getFlightname() {
		return flightname;
	}

	public void setFlightname(String flightname) {
		this.flightname = flightname;
	}

	public int getFlightId() {
		return flightId;
	}

	public void setFlightId(int flightId) {
		this.flightId = flightId;
	}

	public double getFare() {
		return fare;
	}

	public void setFare(double fare) {
		this.fare = fare;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	@Override
	public String toString() {
		return "Flight [flightname=" + flightname + ", flightId=" + flightId + ", fare=" + fare + ", source=" + source
				+ ", destination=" + destination + "]";
	}
	
	
	
	
	
	
	
}
